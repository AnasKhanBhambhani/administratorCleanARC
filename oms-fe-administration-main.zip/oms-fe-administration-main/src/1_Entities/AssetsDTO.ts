import { types } from "mobx-state-tree";

export const Assets = types.model({
  id: types.maybeNull(types.string),
  condition: types.maybeNull(types.string),
  status: types.maybeNull(types.string),
  title: types.maybeNull(types.string),
  purchased_amount: types.maybeNull(types.number),
  purchased_from: types.maybeNull(types.string),
  purchased_date: types.maybeNull(types.string),
  serial_number: types.maybeNull(types.string),
  summary: types.maybeNull(types.string),
  category_id: types.maybeNull(types.string),
  category_title: types.maybeNull(types.string),
  assigned_by_name: types.maybeNull(types.string),
  assigned_to_name: types.maybeNull(types.string),
  authorized_by_name: types.maybeNull(types.string),
  asset_id: types.maybeNull(types.string),
  assigned_by_id: types.maybeNull(types.string),
  assigned_to_id: types.maybeNull(types.string),
  authorized_by_id: types.maybeNull(types.string),
  attributes: types.maybeNull(types.array(types.string)),
});

export interface Asset {
  id: string | null;
  condition: string | null;
  status: string | null;
  title: string | null;
  purchased_amount: number | null;
  purchased_from: string | null;
  purchased_date: string | null;
  serial_number: string | null;
  summary: string | null;
  category_id: string | null;
  category_title: string | null;
  assigned_by_name: string | null;
  assigned_to_name: string | null;
  authorized_by_name: string | null;
  asset_id: string | null;
  assigned_by_id: string | null;
  assigned_to_id: string | null;
  authorized_by_id: string | null;
  attributes: string[] | null;
}
