// import { BaseApi } from "../../baseApi/BaseApi";
// import {Asset} from "../../../1_Entities/AssetsDTO"
// import { assetUrl } from "../../baseApi/Api_route";

// class AssetsApi extends BaseApi{
//     setAssets = async(data) => {
//         try {
//             const response = await this.axios.post(assetUrl, data);
//             // console.log("data",response.data);
//             return response.data;
//           } catch (error) {
//             throw error;
//           }
//     }
// }

// export default AssetsApi;
