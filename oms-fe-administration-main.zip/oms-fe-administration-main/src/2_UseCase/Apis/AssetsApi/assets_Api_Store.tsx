// import { types, flow } from "mobx-state-tree";
// import AssetsApi from "./assets_Api"; // Adjust the path as needed
// import { Assets } from "../../../1_Entities/AssetsDTO"; // Ensure Assets is a MobX State Tree type

// export const AssetsStore = types
//   .model({
//     assets: types.optional(types.array(Assets), []),
//     isLoading: types.optional(types.boolean, false),
//   })
//   .actions((self) => {
//     const api = new AssetsApi();

//     return {
//       addAsset: flow(function* (data) {
//         self.isLoading = true;
//         try {
//           const response = yield api.setAssets(data);
//           self.assets.push(response);
//         } catch (error) {
//           console.error("Failed to add asset:", error);
//         } finally {
//           self.isLoading = false;
//         }
//       }),
//     };
//   });
