export const isProduction = () => {
  const url = window.location.href;
  return url.includes("https://oms.enigmatix.co");
};
export const isProductionServer = isProduction();
export const baseUrl = process.env.REACT_APP_BASE_URL;
export const baseurlV2 = process.env.REACT_APP_BASE_URL_V2;
export const baseUrlStart = process.env.REACT_APP_BASE_URL_START;
export const imgBaseUrl = process.env.REACT_APP_IMAGE_BASE_URL;
// micro-services URLS
export const baseServiceUrl = process.env.REACT_APP_BASE_SERVICE_URL;
export const accountServiceUrl = process.env.REACT_APP_ACCOUNT_SERVICE_URL;
export const employeeServiceUrl = process.env.REACT_APP_EMPLOYEE_SERVICE_URL;
export const hrServicesUrl = process.env.REACT_APP_HR_SERVICE_URL;
export const administrationUrl =
  process.env.REACT_APP_ADMINISTRATION_SERVICE_URL;

// encryption key
export const secretEncryptionKey = process.env.REACT_APP_ENCRYPTION_KEY;
//base services URLs
export const getUserUrl = `${baseServiceUrl}employee/?login=true`;
export const loginUrl = `${baseServiceUrl}login/`;
export const userLevelUrl = `${baseServiceUrl}user-level/`;
export const passwordResetUrl = `${baseServiceUrl}password_reset/`;
export const confirmPasswordUrl = `${baseServiceUrl}password_reset/confirm/`;

// HR service URLS
export const resignationUrl = `${hrServicesUrl}resignation/`;
export const terminationUrl = `${hrServicesUrl}termination/`;
export const clearanceUrl = `${hrServicesUrl}employee-clearance/`;
export const onboardingUrl = `${hrServicesUrl}onboarding/`;
export const onboardingHistoryUrl = `${hrServicesUrl}employ_onboarded/onboarding-history/`;
export const employeeEmpUrl = `${employeeServiceUrl}employee`;

// Administration service Urls
export const assetUrl = `${administrationUrl}dashboard/asset`;
