import axios, {
  AxiosError,
  AxiosInstance,
  AxiosRequestConfig,
  AxiosResponse,
  CancelToken,
  CancelTokenSource,
  InternalAxiosRequestConfig,
} from "axios";
import { camelCase, isArray, isObject, mapKeys, mapValues } from "lodash";

import { decrypt } from "./Api-utils";

const tokenSources: {
  [key: string]: CancelTokenSource;
} = {};

export type ApiErrorType = {
  statusCode: number;
  errorCode: string;
  message: string;
};

async function onCancelRequest(config: InternalAxiosRequestConfig) {
  if (config.cancelToken) {
    const key = config.url;
    let tokenSource = tokenSources[key ?? 0];
    if (tokenSource && tokenSource?.cancel) {
      tokenSource?.cancel("Operation canceled due to new request");
    }
    tokenSource = axios.CancelToken.source();
    config.cancelToken = tokenSource.token;
    tokenSources[key ?? 0] = tokenSource;
  }

  return config;
}

async function onError(
  error: AxiosError,
  axiosInstance: AxiosInstance,
  errorList?: ApiErrorType[]
) {
  let throwError = true;
  if (axios.isCancel(error)) {
    console.warn(error);
    return Promise.resolve({ data: { isCancel: true } });
  }
  const { response } = error;
  if (!response) {
  } else {
    const { status } = response;
    if (errorList && errorList?.length) {
      const errorItem = errorList
        .filter(
          (err) => err.statusCode === status && err.errorCode === errorItem.code
        )
        .pop();
      if (errorItem) {
        throwError = false;
      }
    }
  }
  if (throwError) {
    throw error;
  }
}

function keysToCamelCase<T>(obj: T): T {
  if (isArray(obj)) {
    // @ts-ignore
    return obj.map(keysToCamelCase);
  }
  if (!isObject(obj)) {
    return obj;
  }
  const fixedKeys = mapKeys(obj, (value, key) => camelCase(key));
  // @ts-ignore
  return mapValues(fixedKeys, keysToCamelCase);
}

function transformResponse(data: any): any {
  return keysToCamelCase(data);
}

function getDefaultTransformResponse(): any[] {
  const axiosDefault = axios.defaults.transformResponse;
  if (axiosDefault == null) {
    return [transformResponse];
  }
  if (isArray(axiosDefault)) {
    return axiosDefault?.concat(transformResponse);
  }
  return [axiosDefault, transformResponse];
}

const CAMEL_CASE_DEFAULT_CONFIG: AxiosRequestConfig = {
  transformResponse: getDefaultTransformResponse(),
};

export class BaseApi {
  axios: AxiosInstance;
  axiosWithoutAuth: AxiosInstance;
  cancelToken: CancelToken;

  constructor(baseURL?: string) {
    const sharedConfig = {
      ...CAMEL_CASE_DEFAULT_CONFIG,
      baseURL,
    };

    this.axios = axios.create(sharedConfig);
    this.axios.interceptors.request.use(onCancelRequest);
    this.axiosWithoutAuth = axios.create(sharedConfig);
    this.cancelToken = axios.CancelToken.source().token;

    this.axios.interceptors.request.use(
      this.handleRequest,
      this.handleRequestError
    );
  }

  handleResponseSuccess = (res: AxiosResponse) => res;

  handleRequest = async (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem("token");
    const decryptedToken = decrypt(token);

    if (token) {
      config.headers["Authorization"] = "Bearer " + decryptedToken;
    }

    config.headers["x-tenant"] = "enigmatix";

    return config;
  };

  handleRequestError = (error: AxiosError) => onError(error, this.axios);
}
