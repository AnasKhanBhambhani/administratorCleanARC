// import { types } from "mobx-state-tree";
// import { AssetsStore } from "../Apis/AssetsApi/assets_Api_Store";

// export const RootStore = types.model({
//   assetsStore: AssetsStore,
// });

// export const rootStore = RootStore.create({
//   assetsStore: {
//     assets: [],
//   },
// });
