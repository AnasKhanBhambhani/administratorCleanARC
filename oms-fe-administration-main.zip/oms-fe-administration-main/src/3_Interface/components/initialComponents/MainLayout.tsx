import React from "react";
import Routing from "../../../4_UI/route_service/Router";
import { observer } from "mobx-react-lite";
import Styled from "styled-components";
export const PublicLayout: React.FC = () => {
  return (
    <StyledDashboardWrapper id="OMS-Container">
      <Routing />
    </StyledDashboardWrapper>
  );
};
const DefaultLayout = observer(() => {
  return <PublicLayout />;
});
export default DefaultLayout;
const StyledDashboardWrapper = Styled.div`
  z-index: 54;
`;
