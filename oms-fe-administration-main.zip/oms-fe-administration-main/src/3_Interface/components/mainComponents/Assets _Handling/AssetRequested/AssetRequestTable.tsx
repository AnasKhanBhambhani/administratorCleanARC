import { SimpleTable } from "@saad1993/ecl";
import styled from "styled-components";

function AssetRequestTable() {
  const paginationProps = {
    pageSize: 10,
    current: 1,
  };

  const dataSource: any = [
    {
      key: "1",
      name: "Mike",
      assetName: "-",
      teamLead: "Fahad",
      appliedDate: "2024-01-05",
      duration: "2 months",
      reason: "-",
      status: "Approved",
    },
    {
      key: "2",
      name: "John",
      assetName: "-",
      teamLead: "Fahad",
      appliedDate: "2024-02-12",
      duration: "6 days",
      reason: "-",
      status: "Pending",
    },
    {
      key: "3",
      name: "hmza",
      assetName: "-",
      teamLead: "Fahad",
      appliedDate: "2024-02-12",
      duration: "10 days",
      reason: "-",
      status: "Rejected",
    },
  ];

  return (
    <StyledTable>
      <SimpleTable
        border
        className="table custom-pagination"
        columns={[
          {
            dataIndex: "name",
            key: "name",
            title: "Employee Name",
          },
          {
            dataIndex: "assetName",
            key: "assetName",
            title: "Asset Name",
          },
          {
            dataIndex: "teamLead",
            key: "teamLead",
            title: "Team Lead",
          },
          {
            dataIndex: "appliedDate",
            key: "appliedDate",
            title: "Applied Date",
          },
          {
            dataIndex: "duration",
            key: "duration",
            title: "Duration",
          },
          {
            dataIndex: "reason",
            key: "reason",
            title: "Reason",
          },
          {
            dataIndex: "status",
            key: "status",
            title: "Status",
          },
        ]}
        dataSource={dataSource}
        dataUrl="https://jsonplaceholder.typicode.com/users"
        pagination={paginationProps}
        queryParam={{}}
        responseCountParam="count"
        responseDataParam="data"
        scroll={{
          x: "auto",
        }}
        setPageNumber={() => {}}
        setRefreshTable={() => {}}
        setResetTable={() => {}}
        setTotalRecordRemaining={() => {}}
        showHeader
        sizes="small"
        tableLayout="auto"
      />
    </StyledTable>
  );
}

export default AssetRequestTable;

const StyledTable = styled.div`
  .ant-table-container {
    padding: 0px !important;
  }
  .cSWTrA .ant-table-container {
    background: #fff;
    padding: 10px;
    width: 500px;
  }
  .ant-table-content {
    padding-top: 10px !important;
  }
  .ant-pagination {
    display: "none";
    // display: flex !important;
    justify-content: end !important;
    position: relative !important;
    bottom: 0px !important;
  }
`;
