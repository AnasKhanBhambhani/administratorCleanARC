import React from "react";
import { SearchFilter, FormFields } from "@saad1993/ecl";
import styled from "styled-components";

function AssetHandlingFilter() {
  const listsOfCountries = [
    {
      key: 1,
      label: "Pakistan",
      value: "Pakistan",
    },
    {
      key: 2,
      label: "China",
      value: "China",
    },
  ];
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-start",
        marginBottom: "10px",
      }}
    >
      <StyledFilter
        boxShadow="rgba(0, 0, 0, 0.1) 0px 2px 4px"
        clearSearch={() => {}}
        handleDisable
        handleSearch={() => {}}
        height="45px"
        initialValues={{
          search: "",
        }}
        onChange={() => {}}
        onClick={() => {}}
        onReset={() => {}}
        searchValue=""
        width="300px"
      >
        <Styledform>
          <FormFields
            type="select"
            name="country"
            required={true}
            message="country"
            options={listsOfCountries}
            size="large"
          />
        </Styledform>
        <div style={{ width: "360px" }}></div>
      </StyledFilter>
    </div>
  );
}

export default AssetHandlingFilter;

const Styledform = styled.div`
  .ant-select-selector {
    border-radius: 7px !important;
    width: 300px !important;
    height: 2.9rem !important;
  }
`;
const StyledFilter = styled(SearchFilter)`
  .sc-gUjWJS bBSTBh {
    display: flex;
    justify-content: start;
  }
`;
