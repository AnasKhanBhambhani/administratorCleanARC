import React from "react";
import { FormFields, Form } from "@saad1993/ecl";

// interface AssetSubmissionFormProps {
//   closeDrawer: () => void;
// }

export default function AssetSubmissionForm() {
  const listsOfCountries = [
    {
      key: 1,
      label: "Pakistan",
      value: "Pakistan",
    },
    {
      key: 2,
      label: "China",
      value: "China",
    },
  ];

  return (
    <div>
      <Form
        placeholder="Add Submit"
        // onClickSecondButton={closeDrawer} // Assign closeDrawer to cancel button
      >
        <p>Asset</p>
        <FormFields
          type="select"
          name="country"
          width="560px"
          required={true}
          message="country"
          placeholder="Add Attributes"
          options={listsOfCountries}
          size="large"
        />
        <p>Duration</p>
        <FormFields
          type="date-range"
          name="date-range"
          placeholder="Select date-range"
          width="560px"
        />
        <p>Reason</p>
        <FormFields
          type="textarea"
          name="textarea"
          placeholder="Why do you need a leave"
          required={true}
          message="textarea"
          row={8}
          width="560px"
          size="large"
        />
      </Form>
    </div>
  );
}
