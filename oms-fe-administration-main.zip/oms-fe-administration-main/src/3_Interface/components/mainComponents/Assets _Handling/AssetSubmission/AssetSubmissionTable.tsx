import React from "react";
import { SimpleTable } from "@saad1993/ecl";
import styled from "styled-components";
import yes from "../../../../../4_UI/asset/check.png";
import cross from "../../../../../4_UI/asset/cross.png";

interface AssetSubmissionDataType {
  key: string;
  name: string;
  assetName: string;
  received: string;
  submitted: string;
}

function AssetSubmissionTable() {
  const paginationProps = {
    pageSize: 10,
    current: 1,
  };

  const dataSource: any = [
    {
      key: "1",
      name: "Hamza",
      assetName: "Laptop",
      received: "2024-01-10",
      submitted: "2024-06-15",
    },
    {
      key: "2",
      name: "Abdullah",
      assetName: "Laptop",
      received: "2024-02-20",
      submitted: "2024-07-01",
    },
  ];

  return (
    <StyledTable>
      <SimpleTable
        border
        className="table custom-pagination"
        columns={[
          {
            dataIndex: "name",
            key: "name",
            title: "Employee Name",
          },
          {
            dataIndex: "assetName",
            key: "assetName",
            title: "Asset Name",
          },
          {
            dataIndex: "received",
            key: "received",
            title: "Received",
            render: () => <img src={yes} alt="Yes" width="20" />,
          },
          {
            dataIndex: "submitted",
            key: "submitted",
            title: "Submitted",
            render: () => <img src={cross} alt="Cross" width="20" />,
          },
        ]}
        dataSource={dataSource}
        pagination={paginationProps}
        scroll={{
          x: "auto",
        }}
        showHeader
        sizes="small"
        tableLayout="auto"
      />
    </StyledTable>
  );
}

export default AssetSubmissionTable;

const StyledTable = styled.div`
  .ant-table-container {
    padding: 0px !important;
  }
  .ant-table-content {
    padding-top: 10px !important;
  }
  .ant-pagination {
    display: flex !important;
    justify-content: end !important;
    position: relative !important;
    bottom: 0px !important;
  }
`;
