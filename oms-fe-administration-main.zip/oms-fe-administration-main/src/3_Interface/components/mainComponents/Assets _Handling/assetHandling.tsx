import styled from "styled-components";
import { constRoute } from "../../../../4_UI/route/Route_List";
import React, { useState } from "react";
import { SimpleBreadcrumb, Button, Tabs, Drawer } from "@saad1993/ecl";
import AssetHandlingFilter from "./AssetSubmission/AssetHandlingFilter";
import AssetSubmissionTable from "./AssetSubmission/AssetSubmissionTable";
import AssetSubmissionForm from "./AssetSubmission/AssetSubmissionForm";
import AssetRequestTable from "./AssetRequested/AssetRequestTable";

const AssetHandling = () => {
  const [drawerVisible, setDrawerVisible] = useState(false);

  const showDrawer = () => {
    setDrawerVisible(true);
  };

  const closeDrawer = () => {
    setDrawerVisible(false);
  };

  return (
    <div className="categories" style={{ marginLeft: "20px" }}>
      <Headers>
        <div>
          <h3 style={{ fontWeight: "600", marginTop: "30px" }}>
            Asset Handling
          </h3>
          <SimpleBreadcrumb
            items={[
              {
                title: <a href="/">Dashboard</a>,
              },
              {
                title: (
                  <a href={constRoute.assetHandling}>
                    <span style={{ color: "#2D71D8" }}>Asset Handling</span>
                  </a>
                ),
              },
            ]}
            separator="/"
          />
        </div>
        <StyledButton type="primary" shape="round" onClick={showDrawer}>
          Add Request
        </StyledButton>
      </Headers>
      <AssetHandlingFilter />
      <Tabs
        defaultActiveKey="1"
        items={[
          {
            key: "1",
            label: "Asset Submission",
            children: <AssetSubmissionTable />,
          },
          {
            key: "2",
            label: "Asset Requested",
            children: <AssetRequestTable />,
          },
        ]}
      />
      <Drawer
        closeIcon
        keyboard
        onClose={closeDrawer}
        open={drawerVisible}
        mask
        maskClosable
        title="Add Request"
        width={600}
      >
        <AssetSubmissionForm />
      </Drawer>
    </div>
  );
};

export default AssetHandling;

const Headers = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const StyledButton = styled(Button)`
  background: #2d71d8;
  display: flex;
  justify-content: flex-end;
  gap: 150px;
  height: 2.5rem;
  margin-right: 40px;
`;
