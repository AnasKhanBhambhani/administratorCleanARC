import { useState } from "react";
import styled from "styled-components";
import AssetsApplyForm from "./assetsApplyForm";
import { SimpleBreadcrumb, Button, Tabs, Drawer } from "@saad1993/ecl";
import AssetApproval from "./assetApproval/assetApproval";
import AssetCol from "./assetCol/assetCol";

function Assets() {
  const [drawerVisible, setDrawerVisible] = useState(false);
  const showDrawer = () => {
    setDrawerVisible(true);
  };

  const closeDrawer = () => {
    setDrawerVisible(false);
  };

  return (
    <div style={{ marginLeft: "10px" }}>
      <Headers>
        <div>
          <h3 style={{ fontWeight: "600", marginTop: "30px" }}>Assets</h3>
          <SimpleBreadcrumb
            items={[
              {
                title: <a href="/">Dashboard</a>,
              },
              {
                title: <span style={{ color: "#2D71D8" }}>Assets</span>,
              },
            ]}
            separator="/"
          />
        </div>
        <StyledButton type="primary" shape="round" onClick={showDrawer}>
          Add Request
        </StyledButton>
      </Headers>
      <Tabs
        defaultActiveKey="1"
        items={[
          {
            key: "1",
            label: "Assets",
            children: <AssetCol />,
          },
          {
            key: "2",
            label: "Assets For Approval",
            children: <AssetApproval />,
          },
        ]}
      />
      <Drawer
        closeIcon
        keyboard
        onClose={closeDrawer}
        open={drawerVisible}
        mask
        maskClosable
        title="Add Assets"
        width={800}
      >
        <AssetsApplyForm />
      </Drawer>
    </div>
  );
}

export default Assets;

const Headers = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const StyledButton = styled(Button)`
  background: #2d71d8;
  display: flex;
  justify-content: flex-end;
  gap: 150px;
  height: 2.5rem;
  margin-right: 40px;
`;
