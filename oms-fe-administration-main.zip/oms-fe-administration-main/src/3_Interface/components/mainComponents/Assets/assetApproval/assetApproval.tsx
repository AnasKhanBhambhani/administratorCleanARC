import React from "react";
import AssetApprovalFilter from "./assetsApprovalFilter";
import AssetApprovalTable from "./assetsApprovalTable";

function AssetApproval() {
  return (
    <div>
      <AssetApprovalFilter />
      <AssetApprovalTable />
    </div>
  );
}

export default AssetApproval;
