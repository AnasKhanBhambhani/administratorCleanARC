import React from "react";
import { SearchFilter, FormFields } from "@saad1993/ecl";
import styled from "styled-components";

function AssetApprovalFilter() {
  const listsOfCountries = [
    {
      key: 1,
      label: "Pakistan",
      value: "Pakistan",
    },
    {
      key: 2,
      label: "China",
      value: "China",
    },
  ];
  return (
    <StyledDiv
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "flex-start",
        marginBottom: "10px",
      }}
    >
      <SearchFilter
        boxShadow="rgba(0, 0, 0, 0.1) 0px 2px 4px"
        clearSearch={() => {}}
        handleDisable
        handleSearch={() => {}}
        height="45px"
        initialValues={{
          search: "",
        }}
        onChange={() => {}}
        onClick={() => {}}
        onReset={() => {}}
        width="250px"
      >
        <Styledform>
          <FormFields
            type="select"
            name="country"
            required={true}
            placeholder="Assets Category"
            message="country"
            options={listsOfCountries}
            size="large"
          />
        </Styledform>
      </SearchFilter>
    </StyledDiv>
  );
}

export default AssetApprovalFilter;

const Styledform = styled.div`
  .ant-select-selector {
    border-radius: 7px !important;
    width: 250px !important;
    height: 2.9rem !important;
  }
`;
const StyledDiv = styled.div`
  .ant-form {
    display: flex !important;
    flex-wrap: wrap !important;
    justify-content: start !important;
  }
  form {
    @media (max-width: 750px) {
      flex-direction: column !important;
      width: 100% !important;
      gap: 10px !important;
      margin-right: 0;
      margin-bottom: 10px !important;
      .ant-form-item {
        margin-bottom: 20px;
      }
    }
    > div {
      @media (max-width: 750px) {
        flex-direction: column !important;
        margin-top: 5px;
        width: 100% !important;
        margin-bottom: 10px !important;
        .ant-form-item {
          margin-bottom: 20px;
        }
      }
      > div {
        padding: 0 !important;
        .ant-form-item {
          margin-bottom: 20px;
        }
      }
    }
  }
`;
