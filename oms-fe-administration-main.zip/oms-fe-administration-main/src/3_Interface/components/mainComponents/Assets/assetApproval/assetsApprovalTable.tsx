import { SimpleTable, FormFields, Drawer } from "@saad1993/ecl";
import Approved from "../../../../../4_UI/asset/Approved.png";
import Reject from "../../../../../4_UI/asset/reject.png";
import Pending from "../../../../../4_UI/asset/pending.png";
import styled from "styled-components";

export default function AssetApprovalTable() {
  const renderStatus = (status: string) => {
    return (
      <div style={{ flexDirection: "row" }}>
        <div>
          <div
            style={{
              width: "7rem",
              backgroundColor: "rgb(248, 244, 207)",
              borderRadius: "1rem",
              height: "2rem",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <p style={{ marginTop: "5px", color: "rgb(233, 202, 31)" }}>
              Pending
            </p>
          </div>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "start",
            gap: "1rem",
            marginLeft: "2em",
            marginTop: "5px",
          }}
        >
          <div style={{ display: "flex", gap: "5px" }}>
            <img src={Approved} width={23} height={23} alt="Approved" />
          </div>
          <div style={{ display: "flex", gap: "5px" }}>
            <img src={Reject} width={23} height={23} alt="Rejected" />
          </div>
        </div>
      </div>
    );
  };

  const data: any = [
    {
      key: "1",
      assetName: "Laptop",
      serialNumber: "SN123456",
      assetCategory: "Electronics",
      condition: "New",
      assetExpense: "$1500",
      status: "Approved",
    },
    {
      key: "2",
      assetName: "Office Chair",
      serialNumber: "SN654321",
      assetCategory: "Furniture",
      condition: "Good",
      assetExpense: "$200",
      status: "Pending",
    },
    {
      key: "3",
      assetName: "Projector",
      serialNumber: "SN789123",
      assetCategory: "Electronics",
      condition: "Used",
      assetExpense: "$800",
      status: "Reject",
    },
  ];

  return (
    <StyledDiv>
      <SimpleTable
        border
        className="table"
        columns={[
          {
            dataIndex: "assetName",
            key: "assetName",
            title: "Asset Name",
          },
          {
            dataIndex: "serialNumber",
            key: "serialNumber",
            title: "Serial Number",
          },
          {
            dataIndex: "assetCategory",
            key: "assetCategory",
            title: "Asset Category",
          },
          {
            dataIndex: "condition",
            key: "condition",
            title: "Condition",
          },
          {
            dataIndex: "assetExpense",
            key: "assetExpense",
            title: "Asset Expense",
          },
          {
            dataIndex: "status",
            key: "status",
            title: "Status",
            render: (text: string) => renderStatus(text),
          },
        ]}
        dataSource={data}
        pagination={{
          pageSize: 10,
        }}
        queryParam={{}}
        responseCountParam="count"
        responseDataParam="data"
        scroll={{
          x: "auto",
        }}
        setPageNumber={() => {}}
        setRefreshTable={() => {}}
        setResetTable={() => {}}
        setTotalRecordRemaining={() => {}}
        showHeader
        sizes="small"
        tableLayout="auto"
      />
    </StyledDiv>
  );
}

const StyledDiv = styled.div`
  .ant-table-container {
    box-shadow: 0 0 15px #0000001a;
  }
`;
