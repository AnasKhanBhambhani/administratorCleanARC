import React from "react";
import AssetFilter from "./assetFilter";
import AssetTable from "./assetTable";

function AssetCol() {
  return (
    <div>
      <AssetFilter />
      <AssetTable />
    </div>
  );
}

export default AssetCol;
