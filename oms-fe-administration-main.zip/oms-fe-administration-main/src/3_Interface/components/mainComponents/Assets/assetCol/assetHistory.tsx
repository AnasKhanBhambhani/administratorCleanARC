import React from "react";
import { FormFields, HorizontalTimeline } from "@saad1993/ecl";

function AssetHistory() {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div>
          <p>Asset Name</p>
          <FormFields
            type="text"
            name="name"
            placeholder="Laptop-HP"
            required={true}
            message="Full Name"
            size="large"
            width={350}
          />
          <p>Assets Attribute</p>
          <FormFields
            type="text"
            name="name"
            placeholder="AST-35274"
            required={true}
            message="Full Name"
            size="large"
            width={350}
          />
        </div>
        <div>
          <p>Asset User</p>
          <FormFields
            type="text"
            name="name"
            placeholder="Adil"
            required={true}
            message="Full Name"
            size="large"
            width={350}
          />
          <p>Asset Type</p>
          <FormFields
            type="text"
            name="name"
            placeholder="Laptop"
            required={true}
            message="Full Name"
            size="large"
            width={350}
          />
        </div>
      </div>
      <HorizontalTimeline
        items={[
          {
            content: (
              <>
                <h2>New Year's Day</h2>
                <p>
                  Learn how to write effective paragraphs with topic sentences,
                  introduction, body, and conclusion.
                </p>
              </>
            ),
            date: "2023-01-01",
          },
          {
            content: (
              <>
                <h2>Valentine's Day</h2>
                <p>
                  Celebrate the day of love with thoughtful gestures and gifts.
                </p>
              </>
            ),
            date: "2023-02-14",
          },
          {
            content: (
              <>
                <h2>Independence Day</h2>
                <p>
                  Commemorate the declaration of independence with fireworks and
                  festivities.
                </p>
              </>
            ),
            date: "2023-07-04",
          },
        ]}
        title="Time Line Of Asset"
        titleColor="blue"
        titleStyle={{
          fontSize: "30px",
        }}
      />
    </div>
  );
}

export default AssetHistory;
