import { useState } from "react";
import { SimpleTable, Drawer, FormFields } from "@saad1993/ecl";
import Approved from "../../../../../4_UI/asset/Approved.png";
import Reject from "../../../../../4_UI/asset/reject.png";
import Pending from "../../../../../4_UI/asset/pending.png";
import PopUp from "../../../../../4_UI/asset/popUpAsset.png";
import History from "../../../../../4_UI/asset/HistoryAsset.png";
import Update from "../../../../../4_UI/asset/UpdateAsset.png";
import styled from "styled-components";
import AssetsUpdate from "./assetUpdate";
import AssetHistory from "./assetHistory";

export default function AssetTable() {
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [history, setHistory] = useState(false);

  const showDrawer = () => {
    setDrawerVisible(true);
  };

  const closeDrawer = () => {
    setDrawerVisible(false);
  };

  const showHistoryDrawer = () => {
    setHistory(true);
  };

  const closeHistoryDrawer = () => {
    setHistory(false);
  };

  const dataSource: any = [
    {
      key: "1",
      assetName: "Laptop",
      serialNumber: "SN12345",
      assetCategory: "Electronics",
      assignedTo: "John Doe",
      assignedBy: "Jane Smith",
      condition: "New",
      authorizedBy: "Saad-Bin-Abid",
      assetExpense: "36000",
      status: "Approved",
      action: "Action",
    },
    {
      key: "2",
      assetName: "Projector",
      serialNumber: "SN67890",
      assetCategory: "Electronics",
      assignedTo: "Alice Johnson",
      assignedBy: "Robert King",
      condition: "Used",
      authorizedBy: "Saad-Bin-Abid",
      assetExpense: "20000",
      status: "Reject",
      action: "Action",
    },
    {
      key: "3",
      assetName: "Office Chair",
      serialNumber: "SN54321",
      assetCategory: "Furniture",
      assignedTo: "Emily White",
      assignedBy: "Sophia Harris",
      condition: "Fair",
      authorizedBy: "Saad-Bin-Abid",
      assetExpense: "45000",
      status: "Reject",
      action: "Action",
    },
  ];

  const renderStatus = (status: string) => {
    switch (status) {
      case "Approved":
        return (
          <div style={{ display: "flex", gap: "5px" }}>
            <img src={Approved} width={23} height={23} alt="Approved" />
            <p>Approved</p>
          </div>
        );
      case "Reject":
        return (
          <div style={{ display: "flex", gap: "5px" }}>
            <img src={Reject} width={23} height={23} alt="Rejected" />
            <p>Rejected</p>
          </div>
        );
      default:
        return null;
    }
  };

  const renderAction = () => (
    <div style={{ display: "flex", gap: "5px" }}>
      <img src={Update} alt="Update" onClick={showDrawer} />
      <img src={History} alt="History" onClick={showHistoryDrawer} />
      {/* <img src={PopUp} alt="PopUp" /> */}
    </div>
  );

  const listsOfUsers = [
    { key: "1", label: "John Doe", value: "John Doe" },
    { key: "2", label: "Alice Johnson", value: "Alice Johnson" },
    { key: "3", label: "Emily White", value: "Emily White" },
  ];

  return (
    <StyledDiv>
      <SimpleTable
        border
        className="table"
        columns={[
          {
            width: "150px",
            dataIndex: "assetName",
            key: "assetName",
            title: "Asset Name",
          },
          {
            width: "150px",
            dataIndex: "serialNumber",
            key: "serialNumber",
            title: "Serial Number",
          },
          {
            width: "150px",
            dataIndex: "assetCategory",
            key: "assetCategory",
            title: "Asset Category",
          },
          {
            width: "150px",
            dataIndex: "assignedTo",
            key: "assignedTo",
            title: "Assigned To",
            render: () => (
              <StyledSelect>
                <FormFields
                  type="select"
                  name="assignedTo"
                  required={true}
                  placeholder="Select Assignee"
                  message="assignedTo"
                  options={listsOfUsers}
                  size="large"
                />
              </StyledSelect>
            ),
          },
          {
            width: "150px",
            dataIndex: "assignedBy",
            key: "assignedBy",
            title: "Assigned By",
          },
          {
            width: "150px",
            dataIndex: "condition",
            key: "condition",
            title: "Condition",
          },
          {
            width: "150px",
            dataIndex: "authorizedBy",
            key: "authorizedBy",
            title: "Authorized By",
          },
          {
            width: "150px",
            dataIndex: "assetExpense",
            key: "assetExpense",
            title: "Asset Expense",
          },
          {
            width: "150px",
            dataIndex: "status",
            key: "status",
            title: "Status",
            render: (text: string) => renderStatus(text),
          },
          {
            width: "150px",
            dataIndex: "action",
            key: "action",
            title: "Action",
            render: () => renderAction(),
          },
        ]}
        dataSource={dataSource}
        pagination={{ pageSize: 10 }}
        queryParam={{}}
        responseCountParam="count"
        responseDataParam="data"
        scroll={{ x: "auto" }}
        setPageNumber={() => {}}
        setRefreshTable={() => {}}
        setResetTable={() => {}}
        setTotalRecordRemaining={() => {}}
        showHeader
        sizes="small"
        tableLayout="auto"
      />
      <Drawer
        closeIcon
        keyboard
        onClose={closeDrawer}
        open={drawerVisible}
        mask
        maskClosable
        title="Add Assets"
        width={800}
      >
        <AssetsUpdate />
      </Drawer>
      <Drawer
        closeIcon
        keyboard
        onClose={closeHistoryDrawer}
        open={history}
        mask
        maskClosable
        title="Add Assets"
        width={800}
      >
        <AssetHistory />
      </Drawer>
    </StyledDiv>
  );
}
const StyledSelect = styled.div`
  .ant-select-selector {
    border-radius: 10px !important; /* Adding !important to override any conflicting styles */
    border-color: #00aaff; /* Example of customizing the border color */
  }
`;
const StyledDiv = styled.div`
  flex-direction: row;
  .table .ant-table-cell {
    width: 150px !important;
  }
`;
