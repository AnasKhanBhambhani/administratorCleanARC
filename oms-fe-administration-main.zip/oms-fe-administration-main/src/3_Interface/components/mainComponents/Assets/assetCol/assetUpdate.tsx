import { useState } from "react";
import CustomForm from "@saad1993/ecl/dist/components/Form/CustomFormFeilds/Form";
import { FormFields } from "@saad1993/ecl";
import styled from "styled-components";
import { Modal } from "antd";
// import { keys } from "mobx";

function AssetsUpdate() {
  const listsOfCountries = [
    {
      key: 1,
      label: "Pakistan",
      value: "Pakistan",
    },
    {
      key: 2,
      label: "China",
      value: "China",
    },
  ];
  const listsOfCondition = [
    {
      key: 1,
      label: "New",
      value: "New",
    },
    {
      key: 2,
      label: "Used",
      value: "Used",
    },
    {
      key: 3,
      label: "Repair",
      value: "Repair",
    },
  ];

  const [isAttributeModalOpen, setIsAttributeModalOpen] = useState(false);

  const openAttributeModal = () => {
    setIsAttributeModalOpen(true);
  };

  const closeAttributeModal = () => {
    setIsAttributeModalOpen(false);
  };

  return (
    <div style={{ display: "flex" }}>
      <CustomForm
        FormLayout="horizontal"
        labelAlign="left"
        labelWrap
        onfinish={() => {}}
        onfinishFailed={() => {}}
        placeholder="submit"
        scrollToFirstError
      >
        <StyledDiv style={{ display: "flex", justifyContent: "space-between" }}>
          <div>
            <p>Asset Name</p>
            <FormFields
              type="text"
              name="name"
              defaultValue="Asset Name"
              placeholder="Name"
              required={true}
              message="Full Name"
              size="large"
              width={350}
            />
            <p>Purchase Date</p>
            <FormFields
              type="date"
              name="date"
              placeholder="12/03/2023"
              width={350}
            />
            <p>Purchased Amount</p>
            <FormFields
              type="text"
              name="name"
              defaultValue="Purchased Amount"
              placeholder="$1000"
              required={true}
              message="Full Name"
              size="large"
              width={350}
            />
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <p>Assets Attributes</p>
              <p
                style={{
                  color: "rgb(45, 113, 216)",
                  textDecoration: "underline",
                  cursor: "pointer",
                }}
                onClick={openAttributeModal}
              >
                Add New
              </p>
            </div>
            <FormFields
              type="text"
              name="name"
              defaultValue="Assets Attributes"
              placeholder="Something"
              required={true}
              message="Full Name"
              size="large"
              width={350}
            />
          </div>
          <div>
            <p>Purchase From</p>
            <FormFields
              type="text"
              name="name"
              defaultValue="Purchase From"
              placeholder="Someone"
              required={true}
              message="Full Name"
              size="large"
              width={350}
            />
            <p>Condition</p>
            <FormFields
              type="select"
              name="country"
              placeholder="Select"
              required={true}
              message="country"
              width={350}
              options={listsOfCondition}
              size="large"
            />
            <p>Category</p>
            <FormFields
              type="select"
              name="country"
              placeholder="Please Select"
              required={true}
              message="country"
              width={350}
              options={listsOfCountries}
              size="large"
            />
            <p>Serial Number</p>
            <FormFields
              type="text"
              name="name"
              defaultValue="Serial Number"
              placeholder="Someone"
              required={true}
              message="Full Name"
              size="large"
              width={350}
            />
          </div>
        </StyledDiv>
        <div>
          <p>Summary</p>
          <StyledInput
            type="textarea"
            name="textarea"
            required={true}
            message="textarea"
            row={8}
            width="740px"
            size="large"
          />
        </div>
        <div>
          <p>Attachment</p>
          <FormFields
            type="file"
            name="file"
            placeholder="Drop your attachment here or browse"
            required={true}
            width={740}
            size="large"
          />
        </div>
        <div style={{ height: "4rem" }}></div>
      </CustomForm>

      <StyledModal2
        title="Add Attribute"
        open={isAttributeModalOpen}
        onOk={closeAttributeModal}
        onCancel={closeAttributeModal}
      >
        <p>Name</p>
        <FormFields
          type="text"
          name="attributeName"
          placeholder="Attribute Name"
          required={true}
          message="Please enter an attribute name"
          size="large"
          width={470}
        />
        <p>Value</p>
        <FormFields
          type="text"
          name="attributeValue"
          placeholder="Attribute Value"
          required={true}
          message="Please enter an attribute value"
          size="large"
          width={470}
        />
      </StyledModal2>
    </div>
  );
}

export default AssetsUpdate;

const StyledDiv = styled.div`
  .ant-input {
    border-radius: 10px !important;
    box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px !important;
    height: 40px !important;
  }
  .ant-select-selector {
    border-radius: 10px !important;
  }
`;

const StyledInput = styled(FormFields)`
  border-radius: 10px !important;
  box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px !important;
`;
const StyledModal = styled(Modal)`
  .ant-modal-close-x {
    display: contents !important;
  }
  .ant-input {
    border-radius: 10px !important;
    height: 50px !important;
    box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px !important;
  }
`;
const StyledModal2 = styled(Modal)`
  .ant-modal-close-x {
    display: contents !important;
  }
  .ant-input {
    border-radius: 10px !important;
    height: 40px !important;
    box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px !important;
  }
`;
