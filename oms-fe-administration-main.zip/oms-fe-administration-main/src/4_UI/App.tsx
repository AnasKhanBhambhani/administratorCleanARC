import { useEffect } from "react";
import { Route, BrowserRouter, Routes } from "react-router-dom";
import DefaultLayout from "../3_Interface/components/initialComponents/MainLayout";
import { constRoute } from "./route/Route_List";
import Assets from "../3_Interface/components/mainComponents/Assets/Assets";
import AssetHandling from "../3_Interface/components/mainComponents/Assets _Handling/assetHandling";

const App = () => {
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (token && window.location.pathname === "/login") {
      window.location.pathname = "/";
    }
  }, [token]);

  return (
    <BrowserRouter>
      <Routes>
        <Route path={constRoute.assets} element={<Assets />} />
        <Route path={constRoute.assetHandling} element={<AssetHandling />} />
        <Route path="*" element={<DefaultLayout />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
