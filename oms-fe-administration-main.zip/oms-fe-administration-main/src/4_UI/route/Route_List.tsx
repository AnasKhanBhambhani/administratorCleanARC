export const constRoute = {
  assets: "/administration/assets",
  assetHandling: "/administration/assetHandling",
};
