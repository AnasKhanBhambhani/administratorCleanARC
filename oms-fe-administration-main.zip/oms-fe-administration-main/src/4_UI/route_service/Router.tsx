import React, { useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import { constRoute } from "../route/Route_List";
import Assets from "../../3_Interface/components/mainComponents/Assets/Assets";
import AssetHandling from "../../3_Interface/components/mainComponents/Assets _Handling/assetHandling";

const Routing = () => {
  const location = useLocation();
  useEffect(() => {
    const splitedArr = location.pathname.split("/");
    const titles = splitedArr.pop();
    let doubleWords = titles.charAt(0).toUpperCase() + titles.slice(1);
    if (doubleWords.includes("-") || doubleWords.includes("&")) {
      const splitChar = doubleWords.includes("-") ? "-" : "&";
      const split = doubleWords.split(splitChar);
      const secondWord = split[1].charAt(0).toUpperCase() + split[1].slice(1);
      doubleWords =
        splitChar === "&"
          ? split[0] + " " + "&" + " " + secondWord
          : split[0] + " " + secondWord;
    }
    const pageTitles = {
      "/": "Enigmatix OMS",
      newpage: "Employee Profile",
      "payroll-slip": "Payroll Slip",
    };
    if (splitedArr.includes("payroll-slip")) {
      document.title = pageTitles["payroll-slip"] || doubleWords;
    } else if (splitedArr.includes("newpage")) {
      document.title = pageTitles["newpage"] || doubleWords;
    } else if (location.pathname.includes("project-dashboard")) {
      document.title = "Projects";
    } else {
      document.title = pageTitles[location.pathname] || doubleWords;
    }
  }, [location.pathname]);
  return (
    <Router>
      <Routes>
        <Route path={constRoute.assets} element={<Assets />} />
        <Route path={constRoute.assetHandling} element={<AssetHandling />} />
      </Routes>
    </Router>
  );
};
export default Routing;
