import { render } from "@testing-library/react";
import App from "./4_UI/App";

describe("Root component", () => {
  it("should be in the document", () => {
    const { getByText } = render(<App />);
    expect(getByText(/Testapp is mounted!/i)).toBeInTheDocument();
  });
});
